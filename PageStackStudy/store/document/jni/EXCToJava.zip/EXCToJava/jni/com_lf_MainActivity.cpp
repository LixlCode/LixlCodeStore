#include <string.h>
#include <android/log.h>
#include <jni.h>
#include "Provider.h"
#include "JNITools.h"
#include <stdio.h>
#include "com_lf_MainActivity.h"

//button1 java����jni
jstring Java_com_lf_MainActivity_stringFromJNI(JNIEnv* env, jobject thiz) {
	return env->NewStringUTF("button_1,Hello from JNI ! ");
}

//button2 java����jni������
jstring Java_com_lf_MainActivity_stringFromJNIWithParam(JNIEnv* env, jobject thiz, jstring msg) {
	//��log���庯��
	LOGD("Java_com_lf_MainActivity_stringFromJNIWithParam");
	//jstringתΪ*
	char* pMsg = jstringTochar(env, msg);
	LOGD("pMsg=%s", pMsg);

	char str[100] = { 0 };
	snprintf(str, sizeof(str), "%s %s", "jstring:", pMsg);
	//char*תΪjstring(���ߴ����´���ģ������޸�)
	jstring jMsg = charTojstring(env, str);
	return jMsg;
}

//button3 jni����java
void Java_com_lf_MainActivity_sayHello(JNIEnv* env, jobject thiz) {
	Provider::getInstance()->SayHello(env);
}

//button4 jni����java��������
void Java_com_lf_MainActivity_sayHelloWithParam(JNIEnv* env, jobject thiz,jstring msg, jboolean flag, jint num) {
	bool b = flag;
	LOGD("boolean= %d", b);
	if (b) {
		Provider::getInstance()->SayHelloWithParam(env, jstringTochar(env, msg), num);
	}
}


//button5 jni����java��̬����
void Java_com_lf_MainActivity_callStaticMethod(JNIEnv* env, jobject thiz) {
	Provider::getInstance()->CallStaticJavaMethod(env);
}

jint Java_com_lf_MainActivity_getProvider(JNIEnv* env, jobject thiz)
{
	jint addr = 0;
	addr = (jint)Provider::getInstance();
	return addr;
}


//button6
void Java_com_lf_MainActivity_callMethodButton3(JNIEnv* env, jobject thiz ,jint addr){
	if( addr == 0 )
	return;
	Provider* provider = (Provider*)addr;
	provider->SayHello(env);

}
