
#include <android/log.h>
#include <jni.h>
#define TAG "JNILOG"


#ifndef LOGD
#define LOGD(...) ((void)__android_log_print(ANDROID_LOG_DEBUG, TAG, __VA_ARGS__))
#endif

#ifndef LOGW
#define LOGW(...) ((void)__android_log_print(ANDROID_LOG_WARN, TAG, __VA_ARGS__))
#endif

#ifndef LOGV
#define LOGV(...) ((void)__android_log_print(ANDROID_LOG_VERBOSE, TAG, __VA_ARGS__))
#endif

#ifndef LOGE
#define LOGE(...) ((void)__android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__))
#endif



char* jstringTochar(JNIEnv* env, jstring jstr);

jstring charTojstring(JNIEnv* env, const char* pat);

