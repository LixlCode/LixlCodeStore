#ifndef __PROVIDE_H__
#define __PROVIDE_H__

#include <string.h>
#include <jni.h>

class Provider
{
private:
	Provider();
	Provider(JNIEnv *env, jobject obj);
public:
	~Provider();
	int GetProviderInstance(JNIEnv* env,jclass obj_class);
	void SayHello(JNIEnv* env);
	void SayHelloWithParam(JNIEnv* env, char* msg, int num);
	void CallStaticJavaMethod(JNIEnv* env);

public:
	static Provider* getInstance();
private:
	static Provider* m_pInstance;
};

#endif
