#include "Provider.h"
#include <android/log.h>
#include<string.h>
#include "JNITools.h"
#include <stdio.h>

using namespace std;

//extern JNIEnv* jniEnv;
jobject mObjProvider;
Provider* Provider::m_pInstance = NULL;

Provider::Provider() {

}

Provider::~Provider() {
	if (m_pInstance != NULL)
	{
		delete m_pInstance;
		m_pInstance = NULL;
	}
}

Provider* Provider::getInstance()
{
	if (m_pInstance == NULL)
	{
		m_pInstance = new Provider;
	}
	return m_pInstance;
}

int Provider::GetProviderInstance(JNIEnv* jniEnv, jclass obj_class) {

	if (obj_class == NULL) {
		return 0;
	}
	//Ĭ�Ϲ��캯������������
	jmethodID construction_id = jniEnv->GetMethodID(obj_class, "<init>", "()V");

	if (construction_id == 0) {
		return -1;
	}
	//ͨ��NewObject����������
	mObjProvider = jniEnv->NewObject(obj_class, construction_id);

	if (mObjProvider == NULL) {
		return -1;
	}

	return 1;
}
/**
 * SayHello ---- ���� Java ������������
 */
void Provider::SayHello(JNIEnv* jniEnv) {
	__android_log_print(ANDROID_LOG_ERROR, "JNIMsg", "InitProvider Begin");
	jclass jTestProvider = jniEnv->FindClass("com/lf/TestProvider");
	jmethodID mid = jniEnv->GetMethodID(jTestProvider, "sayHelloShow", "()V");
//����provider
	if (mid != 0) {
		if (GetProviderInstance(jniEnv, jTestProvider) != 1) {
			jniEnv->DeleteLocalRef(jTestProvider);
			return;
		}
	}
	jniEnv->CallVoidMethod(mObjProvider, mid);

}
/**
 * ������
 */
void Provider::SayHelloWithParam(JNIEnv* jniEnv, char* msg, int num) {
	jclass jTestProvider = jniEnv->FindClass("com/lf/TestProvider");
	jmethodID midHelloWithParam = jniEnv->GetMethodID(jTestProvider,
			"sayHelloWithParamShow", "(Ljava/lang/String;)V");
	if (midHelloWithParam != 0) {
		if (GetProviderInstance(jniEnv, jTestProvider) != 1) {
			jniEnv->DeleteLocalRef(jTestProvider);
			return;
		}
	}
	char str[100] = { 0 };
	snprintf(str, sizeof(str), "%s :%d", msg, num);
	jstring jMsg = charTojstring(jniEnv, str);
	jniEnv->CallVoidMethod(mObjProvider, midHelloWithParam, jMsg);
	jniEnv->DeleteLocalRef(jMsg);
}

void Provider::CallStaticJavaMethod(JNIEnv* jniEnv) {
	jclass jTestProvider = jniEnv->FindClass("com/lf/TestProvider");
	jmethodID mid = jniEnv->GetStaticMethodID(jTestProvider,
			"callStaticMethodShow", "()Ljava/lang/String;");
	jniEnv->CallStaticObjectMethod(jTestProvider, mid);
}
