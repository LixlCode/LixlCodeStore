package com.lf;


import android.widget.Toast;

public class TestProvider {
	private int i = 0;
	public TestProvider() {
		// TODO Auto-generated constructor stub
	}

	public void sayHelloShow() {
		Toast.makeText(MainActivity.mContext, "sayHello：你好", Toast.LENGTH_SHORT).show();
	}
	
	public void sayHelloWithParamShow(String s) {
		Toast.makeText(MainActivity.mContext, "sayHelloWithParam :"+ s, Toast.LENGTH_SHORT).show();
		
	}
	
	public static String callStaticMethodShow() {
		Toast.makeText(MainActivity.mContext,  "callStaticMethodShow", Toast.LENGTH_SHORT).show();
		return "Call From C Java Static Method";
	}

}
