package com.lf;

import com.lf.R;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

/**
 * C 调用 Java 例子
 * 
 * @author luxiaofeng
 * 
 */
public class MainActivity extends Activity {
	// 也就是你mk配置文件中的 LOCAL_MODULE := NDK_03
	private static final String libSoName = "NDK_01";
	private static final String tag = "MainActivity";
	int num = 0;
	private int maddr = 0;
	public static Context mContext = null;
	private Button btnClickStatic = null;
	private Button btn1, btn2, btn3, btn4, btn5, btn6;

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		mContext = this;
		initViews();
		maddr = getProvider();
	}

	/**
	 * 初始化控件
	 */
	private void initViews() {

		btn1 = (Button) this.findViewById(R.id.button1);
		btn2 = (Button) this.findViewById(R.id.button2);
		btn3 = (Button) this.findViewById(R.id.button3);
		btn4 = (Button) this.findViewById(R.id.button4);
		btn5 = (Button) this.findViewById(R.id.button5);
		btn6 = (Button) this.findViewById(R.id.button6);
		btn1.setOnClickListener(new OnClickListener() {

			public void onClick(View v) {
				Toast.makeText(getApplicationContext(), stringFromJNI(), Toast.LENGTH_SHORT).show();
			}
		});
		btn2.setOnClickListener(new OnClickListener() {

			public void onClick(View v) {
				String msg = stringFromJNIWithParam("call method with param");
				Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_SHORT).show();
			}
		});
		btn3.setOnClickListener(new OnClickListener() {

			public void onClick(View v) {
				sayHello();
			}
		});
		btn4.setOnClickListener(new OnClickListener() {

			public void onClick(View v) {
				num++;
				sayHelloWithParam("I hava param", true ,num);
			}
		});
//		btn4.setOnClickListener(new OnClickListener() {
//
//			public void onClick(View v) {
//				Toast.makeText(getApplicationContext(), "num : "+sayHelloWithField(), Toast.LENGTH_SHORT).show();
//
//			}
//		});
		btn5.setOnClickListener(new OnClickListener() {

			public void onClick(View v) {
				callStaticMethod();
			}
		});
		btn6.setOnClickListener(new OnClickListener() {

			public void onClick(View v) {
				callMethodButton3(maddr);
			}
		});
	}
	public native int getProvider();
	
	public native String stringFromJNI();
	public native String stringFromJNIWithParam(String s);

	public native void sayHello();
	public native void sayHelloWithParam(String s,boolean isShow, int num);
//	public native String sayHelloWithField();
	
	public native void callStaticMethod();
	public native void callMethodButton3(int addr);

	/**
	 * 载入JNI生成的so库文件
	 */
	static {
		System.loadLibrary(libSoName);
	
	}

}
