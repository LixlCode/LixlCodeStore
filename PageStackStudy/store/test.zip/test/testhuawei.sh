declare -i i=1
while ((i >= -1))
do
#HOME键
adb shell input keyevent 3
#启动地图
adb shell am start com.baidu.BaiduMap
sleep 2
#定位
adb shell input tap 63 719
sleep 2
#HOME键
adb shell input keyevent 3
sleep 1
#启动地图
adb shell am start com.baidu.BaiduMap
sleep 2
#搜索框
adb shell input tap 400 150
sleep 2
#万科结果
adb shell input tap 500 300
sleep 10
#导航
adb shell input tap 425 1155
sleep 13
#退出
adb shell input tap 50 1168
sleep 3
#回退
adb shell input keyevent 3
#回退
#adb shell input tap 750 1200
end=`date +%F" "%T`
echo $i
echo $end
num1=1

if test $[i] -eq $[num1]

then 
    echo 'first time'
	adb shell dumpsys meminfo com.baidu.BaiduMap > vivo_one.txt

fi

num100=100

if test $[i] -eq $[num100]

then 
    echo 'cx'
	adb shell dumpsys meminfo com.baidu.BaiduMap > vivo_100.txt

fi

i=i+1
sleep 1
done
